module hr.algebra.concept_dariodrazenovic {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;
    requires java.rmi;
    requires java.logging;


    opens hr.algebra.concept_dariodrazenovic to javafx.fxml;
    exports hr.algebra.concept_dariodrazenovic;
    opens hr.algebra.concept_dariodrazenovic.model to javafx.fxml;
    exports hr.algebra.concept_dariodrazenovic.model;
    exports hr.algebra.concept_dariodrazenovic.controller;
    opens hr.algebra.concept_dariodrazenovic.controller to javafx.fxml;
    exports hr.algebra.concept_dariodrazenovic.networking;
}