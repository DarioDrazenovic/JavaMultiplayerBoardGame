package hr.algebra.concept_dariodrazenovic.controller;

import hr.algebra.concept_dariodrazenovic.model.GameMove;
import hr.algebra.concept_dariodrazenovic.model.GameState;
import hr.algebra.concept_dariodrazenovic.networking.CommunicationModule;
import hr.algebra.concept_dariodrazenovic.utils.DialogUtils;
import hr.algebra.concept_dariodrazenovic.utils.FileUtils;
import hr.algebra.concept_dariodrazenovic.utils.DocumentationUtils;
import hr.algebra.concept_dariodrazenovic.utils.XmlUtils;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.util.Duration;

import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class HelloController {

    //TOP LEFT LEFT SIDE BUTTONS
    @FXML
    private Button top1LeftLeftButton;
    @FXML
    private Button top2LeftLeftButton;
    @FXML
    private Button top3LeftLeftButton;
    @FXML
    private Button top4LeftLeftButton;

    //TOP LEFT RIGHT SIDE BUTTONS
    @FXML
    private Button top1LeftRightButton;
    @FXML
    private Button top2LeftRightButton;
    @FXML
    private Button top3LeftRightButton;
    @FXML
    private Button top4LeftRightButton;

    //TOP MIDDLE LEFT SIDE BUTTONS
    @FXML
    private Button top1MiddleLeftButton;
    @FXML
    private Button top2MiddleLeftButton;
    @FXML
    private Button top3MiddleLeftButton;
    @FXML
    private Button top4MiddleLeftButton;
    @FXML
    private Button top5MiddleLeftButton;
    @FXML
    private Button top6MiddleLeftButton;
    @FXML
    private Button top7MiddleLeftButton;
    @FXML
    private Button top8MiddleLeftButton;

    //TOP MIDDLE LEFT LEFT SIDE BUTTONS
    @FXML
    private Button top1MiddleLeftLeftButton;
    @FXML
    private Button top2MiddleLeftLeftButton;
    @FXML
    private Button top3MiddleLeftLeftButton;
    @FXML
    private Button top4MiddleLeftLeftButton;
    @FXML
    private Button top5MiddleLeftLeftButton;
    @FXML
    private Button top6MiddleLeftLeftButton;
    @FXML
    private Button top7MiddleLeftLeftButton;
    @FXML
    private Button top8MiddleLeftLeftButton;

    //TOP MIDDLE RIGHT SIDE BUTTONS
    @FXML
    private Button top1MiddleRightButton;
    @FXML
    private Button top2MiddleRightButton;
    @FXML
    private Button top3MiddleRightButton;
    @FXML
    private Button top4MiddleRightButton;
    @FXML
    private Button top5MiddleRightButton;
    @FXML
    private Button top6MiddleRightButton;
    @FXML
    private Button top7MiddleRightButton;
    @FXML
    private Button top8MiddleRightButton;

    //TOP MIDDLE RIGHT RIGHT SIDE BUTTONS
    @FXML
    private Button top1MiddleRightRightButton;
    @FXML
    private Button top2MiddleRightRightButton;
    @FXML
    private Button top3MiddleRightRightButton;
    @FXML
    private Button top4MiddleRightRightButton;
    @FXML
    private Button top5MiddleRightRightButton;
    @FXML
    private Button top6MiddleRightRightButton;
    @FXML
    private Button top7MiddleRightRightButton;
    @FXML
    private Button top8MiddleRightRightButton;

    //TOP RIGHT LEFT SIDE BUTTONS
    @FXML
    private Button top1RightLeftButton;
    @FXML
    private Button top2RightLeftButton;
    @FXML
    private Button top3RightLeftButton;
    @FXML
    private Button top4RightLeftButton;
    @FXML
    private Button top5RightLeftButton;
    @FXML
    private Button top6RightLeftButton;
    @FXML
    private Button top7RightLeftButton;
    @FXML
    private Button top8RightLeftButton;


    //TOP RIGHT RIGHT SIDE BUTTONS
    @FXML
    private Button top1RightRightButton;
    @FXML
    private Button top2RightRightButton;
    @FXML
    private Button top3RightRightButton;
    @FXML
    private Button top4RightRightButton;
    @FXML
    private Button top5RightRightButton;
    @FXML
    private Button top6RightRightButton;
    @FXML
    private Button top7RightRightButton;
    @FXML
    private Button top8RightRightButton;

    @FXML
    private Label wordLabel;
    @FXML
    private TextField guessTextField;
    @FXML
    private Label timerLabel;

    private Timeline timer;
    private int secondsRemaining = 60;
    private int clickCount = 0;
    private final List<Button> allButtons = new ArrayList<>();
    private static Socket my_socket;
    private static String correctGuess;
    @FXML
    private TextField chatTextField;
    @FXML
    private ListView<String> chatListView;
    private static boolean isTurn;

    private static final List<GameMove> gameMoves = new ArrayList<>();
    private static final Lock lock = new ReentrantLock();


    @FXML
    private void initialize() {

        addButtonsToList(
                top1LeftLeftButton, top2LeftLeftButton, top3LeftLeftButton, top4LeftLeftButton,
                top1LeftRightButton, top2LeftRightButton, top3LeftRightButton, top4LeftRightButton,
                top1MiddleLeftButton, top2MiddleLeftButton, top3MiddleLeftButton, top4MiddleLeftButton,
                top5MiddleLeftButton, top6MiddleLeftButton, top7MiddleLeftButton, top8MiddleLeftButton,
                top1MiddleLeftLeftButton, top2MiddleLeftLeftButton, top3MiddleLeftLeftButton, top4MiddleLeftLeftButton,
                top5MiddleLeftLeftButton, top6MiddleLeftLeftButton, top7MiddleLeftLeftButton, top8MiddleLeftLeftButton,
                top1MiddleRightButton, top2MiddleRightButton, top3MiddleRightButton, top4MiddleRightButton,
                top5MiddleRightButton, top6MiddleRightButton, top7MiddleRightButton, top8MiddleRightButton,
                top1MiddleRightRightButton, top2MiddleRightRightButton, top3MiddleRightRightButton, top4MiddleRightRightButton,
                top5MiddleRightRightButton, top6MiddleRightRightButton, top7MiddleRightRightButton, top8MiddleRightRightButton,
                top1RightLeftButton, top2RightLeftButton, top3RightLeftButton, top4RightLeftButton,
                top5RightLeftButton, top6RightLeftButton, top7RightLeftButton, top8RightLeftButton,
                top1RightRightButton, top2RightRightButton, top3RightRightButton, top4RightRightButton,
                top5RightRightButton, top6RightRightButton, top7RightRightButton, top8RightRightButton
        );
    }

    public void initialize(boolean isMyTurn, Socket socket) {
        my_socket = socket;
        isTurn=isMyTurn;
        if (isMyTurn) {
            guessTextField.setText("Not your turn to guess");
            guessTextField.setDisable(true);
            setRandomWord();
        } else {
            wordLabel.setText("Guess the word");
            guessTextField.setOnKeyPressed(event -> {
                if (event.getCode() == KeyCode.ENTER) {
                    submitGuess();
                }
            });

            for (Button button : allButtons) {
                button.setDisable(true);
            }

            new Thread(() -> {
                while (true) {
                    String message = null;
                    try {
                        message = CommunicationModule.receiveMessage(my_socket);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    if (message != null) {
                        System.out.println("Received message from server: " + message);
                        String finalMessage = message;

                        handleReceivedMessage(finalMessage);
                    }
                }
            }, "My Message Receiver Thread").start();
        }
        chatTextField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                String message = chatTextField.getText().trim();
                if (!message.isEmpty()) {
                    CommunicationModule.sendMessage(my_socket, "chat-" + message);
                    chatListView.getItems().add("You: " + message);
                    chatTextField.clear();
                }
            }
        });
    }

    private void handleReceivedMessage(String message) {
        String[] parts = message.split("-");
        if (parts.length == 3) {
            String buttonIdsString = parts[1];
            String word = parts[2];

            String[] buttonIds = buttonIdsString.split(",");
            for (Button button : allButtons) {
                if (Arrays.asList(buttonIds).contains(button.getId())) {
                    button.setStyle("-fx-background-color: red;");
                }
                button.setDisable(true);
            }

            correctGuess = word;
        } else if (parts.length == 2 && parts[0].equals("chat")) {
            String chatMessage = parts[1];

            String[] chatParts = chatMessage.split(" ", 2);
            if (chatParts.length == 2) {
                String timeStamp = chatParts[0];
                String actualMessage = chatParts[1];
                Platform.runLater(() -> chatListView.getItems().add("Opponent (" + timeStamp + "): " + actualMessage));
            }
        }
    }

    private void addButtonsToList(Button... buttons) {
        allButtons.addAll(Arrays.asList(buttons));
    }

    private List<Button> clickedButtonsList = new ArrayList<>();
    @FXML
    private void buttonPressed(Event event) {
        String currentWord = wordLabel.getText();
        if (clickCount < 3) {
            Button buttonPressed = (Button) event.getSource();
            if (buttonPressed.getStyle().equals("")) {
                if (clickCount == 0) {
                    buttonPressed.setStyle("-fx-background-color: blue;");
                } else if (clickCount == 1) {
                    buttonPressed.setStyle("-fx-background-color: red;");
                } else if (clickCount == 2) {
                    buttonPressed.setStyle("-fx-background-color: yellow;");
                    disableAllButtons();
                }
                clickedButtonsList.add(buttonPressed);
                clickCount++;

                List<String> buttonsIDs = new ArrayList<>();
                for(Button btn: clickedButtonsList){
                    buttonsIDs.add(btn.getId());
                }

                GameMove currentMove = new GameMove("Player1", currentWord, LocalDateTime.now(), buttonsIDs);
                XmlUtils.saveGameMove(currentMove);

                if (clickCount == 3) {
                    List<Button> buttonList = new ArrayList<>(clickedButtonsList);

                    String msg = prepareMessage(buttonList, wordLabel.getText());
                    CommunicationModule.sendMessage(my_socket, msg);

                    endTurn();
                    guessTextField.setDisable(false);
                }
            }
        }
    }
    private String prepareMessage(List<Button> clickedButtonsList, String wordLabelText) {
        StringBuilder messageBuilder = new StringBuilder("send-");

        for (Button button : clickedButtonsList) {
            String buttonId = button.getId();
            messageBuilder.append(buttonId).append(",");
        }
        if (!clickedButtonsList.isEmpty()) {
            messageBuilder.deleteCharAt(messageBuilder.length() - 1);
        }
        messageBuilder.append("-").append(wordLabelText);

        return messageBuilder.toString();
    }


    private void submitGuess() {
        String enteredGuess = guessTextField.getText().trim();
        String correctWord = correctGuess;

            if (enteredGuess.equalsIgnoreCase(correctWord)) {
                System.out.println("Correct guess!");
                stopTimer();
                DialogUtils.displayWinner();
                endTurn();
            } else {
                System.out.println("Incorrect guess!");
            }

    }

    private void endTurn(){
        try {
            resetTurn();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void resetTurn() throws IOException {
        for (Button button : allButtons) {
            if (button != null) {
                button.setStyle("");
                button.setDisable(false);
            }
        }
        guessTextField.clear();
        setRandomWord();
        clickCount = 0;
        resetTimer();
        isTurn = !isTurn;
        initialize(isTurn, my_socket);
    }

    private void startTimer() {
        if (timer == null) {
            timer = new Timeline(new KeyFrame(Duration.seconds(1), this::updateTimer));
            timer.setCycleCount(Timeline.INDEFINITE);
            timer.play();
        }
    }

    private void resetTimer() {
        stopTimer();
        secondsRemaining = 60;
        timer = null;
    }

    private void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }

    private void updateTimer(ActionEvent event) {
        secondsRemaining--;
        if (secondsRemaining <= 0) {
            endTurn();
        }
        timerLabel.setText("Time: " + secondsRemaining + "s");
    }

    private void disableAllButtons() {
        for (Button button : allButtons) {
            if (button != null) {
                button.setDisable(true);
            }
        }
    }

    private final List<String> wordList = Arrays.asList("Lion", "Beatles", "Tesla");

    private void setRandomWord() {
        Collections.shuffle(wordList);
        String randomWord = wordList.get(0);
        wordLabel.setText(randomWord);
    }

    @FXML
    private void saveGame() {
        List<String> clickedButtonIds = extractClickedButtons();
        String correctWord = wordLabel.getText().trim();
        boolean threeClicksDone = clickCount == 3;
        GameState gameState = new GameState(clickedButtonIds, secondsRemaining, clickCount, correctWord, threeClicksDone);
        FileUtils.saveGame(gameState);
        DialogUtils.displaySaveSuccessMessage();
    }

    private List<String> extractClickedButtons() {
        List<String> clickedButtons = new ArrayList<>();

        for (Button button : allButtons) {
            if (button != null && !button.getStyle().isEmpty()) {
                String buttonId = button.getId();
                clickedButtons.add(buttonId);
            }
        }

        return clickedButtons;
    }


    @FXML
    private void loadGame() {
        GameState recoveredGameState = FileUtils.loadGame();
        if (recoveredGameState != null) {
            String correctWord = recoveredGameState.getCorrectWord();
            boolean threeClicksDone = recoveredGameState.isThreeClicksDone();

            secondsRemaining = recoveredGameState.getSecondsRemaining();
            clickCount = recoveredGameState.getClickCount();

            setClickedButtonsStyles(recoveredGameState.getClickedButtons());

            wordLabel.setText(correctWord);

            if (threeClicksDone) {
                disableAllButtons();
                startTimer();
            }
            DialogUtils.displayLoadSuccessMessage();
        } else {
            DialogUtils.displayLoadErrorMessage();
        }
    }
    private void setClickedButtonsStyles(List<String> clickedButtonIds) {
        for (Button button : allButtons) {
            if (button != null && clickedButtonIds.contains(button.getId())) {
                button.setStyle("-fx-background-color: red;");
                button.setDisable(true);
            }
        }
    }

    public void generateHtmlDocumentation() {
        DocumentationUtils.generateDocumentation();
    }

    @FXML
    private void replayGame() {
        endTurn();
        resetTimer();
        clickCount = 0;

        gameMoves.clear();

        Thread readThread = new Thread(() -> {
            XmlUtils.readGameMovesAndReplay(this);
        }, "My Replay Game Thread");
        readThread.start();
    }

    public void replayMove(GameMove gameMove) {
        lock.lock();
        try {
            System.out.println("Lock acquired in replayMove method.");

            Platform.runLater(() -> {
                setClickedButtonsStylesForReplay(gameMove.getClickedButtons());
                wordLabel.setText(gameMove.getWord());
                clickCount++;

                if (clickCount == 3) {
                    endTurn();
                    guessTextField.setDisable(false);
                }
            });
        } finally {
            lock.unlock();
            System.out.println("Lock released in replayMove method.");
        }

        System.out.println("Move replayed..");

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void setClickedButtonsStylesForReplay(List<String> clickedButtonIds) {
        for (Button button : allButtons) {

            if (button != null && clickedButtonIds.contains(button.getId())) {
                button.setStyle("-fx-background-color: red;");
                button.setDisable(true);
            }
        }
    }
}