package hr.algebra.concept_dariodrazenovic.networking;
import hr.algebra.concept_dariodrazenovic.model.Message;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
public interface MessengerService extends Remote{

    void sendMessage(Message chatMessage) throws RemoteException;

    List<Message> getAllMessages() throws RemoteException;

    Message getLastMessage() throws RemoteException;

    void clearMessages() throws RemoteException;

}