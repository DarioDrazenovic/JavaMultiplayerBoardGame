package hr.algebra.concept_dariodrazenovic.networking;

import java.io.*;
import java.net.*;

public class CommunicationModule {
    public static void sendMessage(Socket socket, String message) {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println(message);
        } catch (IOException e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }

    public static String receiveMessage(Socket socket) throws IOException {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            return in.readLine();

        } catch (IOException e) {
            System.err.println("Error receiving message: " + e.getMessage());
            return e.getMessage();
        }
    }
}



