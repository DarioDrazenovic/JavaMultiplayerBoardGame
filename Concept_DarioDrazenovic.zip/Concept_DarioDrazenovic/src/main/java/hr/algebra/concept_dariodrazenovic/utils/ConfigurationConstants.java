package hr.algebra.concept_dariodrazenovic.utils;

public class ConfigurationConstants {
    public static final String HOST = "localhost";
    public static final int PORT = 1989;
}
