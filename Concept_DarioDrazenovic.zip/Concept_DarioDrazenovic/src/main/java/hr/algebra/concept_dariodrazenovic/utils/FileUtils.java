package hr.algebra.concept_dariodrazenovic.utils;

import hr.algebra.concept_dariodrazenovic.model.GameState;
import javafx.scene.control.Button;

import java.io.*;

public class FileUtils {

    private static final String FILE_PATH = "gamestate.dat";

    public static void saveGame(GameState gameState) {
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            outputStream.writeObject(gameState);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static GameState loadGame() {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            return (GameState) inputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}