package hr.algebra.concept_dariodrazenovic.model;

public enum UserRole {
    SERVER, CLIENT
}
