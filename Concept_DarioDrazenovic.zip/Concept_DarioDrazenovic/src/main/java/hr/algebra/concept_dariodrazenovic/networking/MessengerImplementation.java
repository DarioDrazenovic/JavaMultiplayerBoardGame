package hr.algebra.concept_dariodrazenovic.networking;

import hr.algebra.concept_dariodrazenovic.model.Message;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class MessengerImplementation implements MessengerService{

    List<Message> messages = new ArrayList<>();

    @Override
    public void sendMessage(Message chatMessage) throws RemoteException {
        messages.add(chatMessage);
    }

    @Override
    public List<Message> getAllMessages() throws RemoteException {
        return messages;
    }

    @Override
    public Message getLastMessage() throws RemoteException {
        if (!messages.isEmpty()) {
            return messages.get(messages.size() - 1);
        }
        return null;
    }

    @Override
    public void clearMessages() throws RemoteException {
        messages.clear();
    }
}