package hr.algebra.concept_dariodrazenovic.networking;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.*;

public class Server {
    public static final int PORT = 1989;
    private static int connectedClients = 0;

    private static List<Socket> clientSockets = new ArrayList<>();
    public static void main(String[] args) {
        acceptRequests();
    }

    private static void acceptRequests() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)){
            System.err.println("Server listening on port: " + serverSocket.getLocalPort());

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.err.println("Client connected from port: " + clientSocket.getPort());
                clientSockets.add(clientSocket);
                new Thread(() -> {
                    try {
                        processClient(clientSocket);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }).start();
                connectedClients++;
            }
        }  catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void sendMessageToClient(Socket socket, String message) {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println(message);
        } catch (IOException e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }


    private static void processClient(Socket clientSocket) throws IOException {
       while (true) {
           String receivedMessage = receiveMessage(clientSocket);

           if(receivedMessage.contains("Socket is closed") || receivedMessage.contains("Connection reset")){
               System.out.println("Socket is closed");
               break;
           }

           handleReceivedMessage(clientSocket, receivedMessage);
       }
    }

    private static void handleReceivedMessage(Socket clientSocket, String receivedMessage) {
        System.out.println("Received message from client on port " + clientSocket.getPort() + ": " + receivedMessage);

        if ("connected".equals(receivedMessage)) {
            String turnMessage = checkTurns();
            sendMessageToClient(clientSocket,turnMessage);
        } else if (receivedMessage.startsWith("send-")) {
            // Extract the other player's socket
            Socket otherPlayerSocket = getOtherPlayerSocket(clientSocket);

            if (otherPlayerSocket != null) {
                // Send the received message to the other player
                CommunicationModule.sendMessage(otherPlayerSocket, receivedMessage);
            }
        }else if (receivedMessage.startsWith("chat-")) {
            String chatMessage = receivedMessage.substring(5); // Uzimanje dijela poruke nakon "chat-"
            broadcastChatMessage(clientSocket, chatMessage);
        }
    }
    private static void broadcastChatMessage(Socket sender, String message) {
        String timeStamp = new SimpleDateFormat("HH:mm:ss").format(new Date());

        for (Socket socket : clientSockets) {
            if (socket != sender) {
                System.out.println("Sending chat message to client on port " + socket.getPort());
                sendMessageToClient(socket, "chat-" + timeStamp + " " + message);
            }
        }
    }

    private static Socket getOtherPlayerSocket(Socket currentPlayerSocket) {
        for (Socket socket : clientSockets) {
            if (socket != currentPlayerSocket) {
                return socket;
            }
        }
        return null;
    }

    private static String checkTurns() {
        if (clientSockets.size() == 1) {
            return "turn";
        } else {
            return "not turn";
        }
    }


    public static String receiveMessage(Socket socket) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            return in.readLine();

        } catch (IOException e) {
            System.err.println("Error receiving message: " + e.getMessage());
            clientSockets.remove(socket);
            return e.getMessage();
        }
    }

}
