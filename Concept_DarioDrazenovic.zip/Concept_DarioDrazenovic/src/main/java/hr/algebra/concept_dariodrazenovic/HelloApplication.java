package hr.algebra.concept_dariodrazenovic;

import hr.algebra.concept_dariodrazenovic.controller.HelloController;
import hr.algebra.concept_dariodrazenovic.model.UserRole;
import hr.algebra.concept_dariodrazenovic.networking.MessengerImplementation;
import hr.algebra.concept_dariodrazenovic.networking.MessengerService;
import hr.algebra.concept_dariodrazenovic.utils.ConfigurationConstants;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HelloApplication extends Application {

    public static UserRole activeUserRole;
    private static boolean isMyTurn;
    private static Socket clientSocket;


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Parent root = fxmlLoader.load();

        // Pass the isMyTurn flag to the controller
        HelloController controller = fxmlLoader.getController();
        controller.initialize(isMyTurn, clientSocket);

        Scene scene = new Scene(root, 1720, 1020);
        stage.setTitle("Concept");
        stage.setScene(scene);
        stage.show();
    }

    private static void startClient(){
        startGameClient();
    }

    private static void startGameClient() {
        try {
            clientSocket = new Socket(ConfigurationConstants.HOST, ConfigurationConstants.PORT);
            System.err.println("Client is connecting to " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());
            sendMessageToServer(clientSocket, "connected");
            // Set up message listener to handle turn/not turn messages
            new Thread(() -> {
                try {
                    listenToServerMessages(clientSocket);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void sendMessageToServer(Socket socket, String message) {
        try {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println(message);
        } catch (IOException e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }

    private static void listenToServerMessages(Socket clientSocket) throws IOException {
        while (true) {
            String receivedMessage = receiveMessage(clientSocket);

            if(receivedMessage!=null){
                new Thread(() -> handleReceivedMessage(receivedMessage)).start();

                if(receivedMessage.contains("turn")){
                    break;
                }
            }
        }
    }

    private static void handleReceivedMessage(String receivedMessage) {
        System.out.println("Received message from server: " + receivedMessage);

        if(receivedMessage.contains("turn")){
            handleTurnMessage(receivedMessage);
        }

    }
    private static void handleTurnMessage(String turnMessage) {
        isMyTurn = turnMessage.equals("turn");
        launch();
    }

    public static String receiveMessage(Socket socket) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            return in.readLine();

        } catch (IOException e) {
            System.err.println("Error receiving message: " + e.getMessage());
            return e.getMessage();
        }
    }

    public static void main(String[] args) {
        String userRoleLoggedIn = "CLIENT";
        Boolean userLoggedIn = false;
        activeUserRole = UserRole.CLIENT;

        for(UserRole userRole : UserRole.values()) {
            if(userRole.name().equals(userRoleLoggedIn)) {
                userLoggedIn = true;
                activeUserRole = userRole;
            }
        }

        if(userLoggedIn) {
            startClient();
        }
    }
}