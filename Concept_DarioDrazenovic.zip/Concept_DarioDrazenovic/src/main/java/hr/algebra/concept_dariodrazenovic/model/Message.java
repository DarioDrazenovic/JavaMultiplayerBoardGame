package hr.algebra.concept_dariodrazenovic.model;
import java.io.Serializable;
import java.time.LocalDateTime;
public class Message implements Serializable{

    private static final long serialVersionUID = 1L;

    private String playerNickname;
    private String message;
    private LocalDateTime time;


    public Message(String username, String message, LocalDateTime time) {
        this.playerNickname = username;
        this.message = message;
        this.time = time;
    }

    public String getPlayer() {
        return playerNickname;
    }

    public void setPlayer(String user) {
        this.playerNickname = user;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "Message{" + "playerNickname=" + playerNickname + ", message=" + message + ", time=" + time + '}';
    }

}
