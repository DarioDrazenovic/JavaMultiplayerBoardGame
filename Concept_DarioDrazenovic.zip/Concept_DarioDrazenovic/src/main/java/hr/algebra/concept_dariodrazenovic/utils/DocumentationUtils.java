package hr.algebra.concept_dariodrazenovic.utils;

import javafx.scene.control.Alert;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class DocumentationUtils {
    public static void generateDocumentation(){

        try {
            List<String> classFileNames = Files.walk(Paths.get("target"))
                    .map(Path::toString)
                    .filter(string -> string.endsWith(".class"))
                    //.forEach(entry ->System.out.println(entry.toString()));
                    .filter(string -> !string.endsWith("module-info.class"))
                    .toList();

            String htmlHeader = """
            <!DOCTYPE html>
            <html>
            <head>
            <title>Page Title</title>
            </head>
            <body>
            """;

            for (String path : classFileNames){
                System.out.println("Path: " + path);
                String[] pathTokens = path.split("classes");
                String secondToken = pathTokens[1];
                String fullyQualifiedNameWithBackslashes = secondToken.substring(1, secondToken.lastIndexOf('.'));
                String fullyQuallifiedName = fullyQualifiedNameWithBackslashes.replace('\\', '.');
                //System.out.println("FQN: " + fullyQuallifiedName);

                htmlHeader += "<h2>" + fullyQuallifiedName + "</h2>";
                Class<?> deserializedClass = Class.forName(fullyQuallifiedName);

                Field[] fields = deserializedClass.getDeclaredFields();

                for (Field field : fields) {
                    htmlHeader += "<h3>";

                    int modifiers = field.getModifiers();

                    if (Modifier.isPublic(modifiers)) {
                        htmlHeader += "public ";
                    } else if (Modifier.isPrivate(modifiers)) {
                        htmlHeader += "private ";
                    } else if (Modifier.isProtected(modifiers)) {
                        htmlHeader += "protected ";
                    }
                    if (Modifier.isStatic(modifiers)) {
                        htmlHeader += "static ";
                    }
                    if (Modifier.isFinal(modifiers)) {
                        htmlHeader += "final ";
                    }

                    htmlHeader += field.getType().getTypeName() + " ";
                    htmlHeader += field.getName() + "\n";

                    htmlHeader += "</h3>";
                }
                Method[] methods = deserializedClass.getDeclaredMethods();
                for (Method method : methods) {
                    htmlHeader += "<h3>";

                    int modifiers = method.getModifiers();

                    if (Modifier.isPublic(modifiers)) {
                        htmlHeader += "public ";
                    } else if (Modifier.isPrivate(modifiers)) {
                        htmlHeader += "private ";
                    } else if (Modifier.isProtected(modifiers)) {
                        htmlHeader += "protected ";
                    }
                    if (Modifier.isStatic(modifiers)) {
                        htmlHeader += "static ";
                    }
                    if (Modifier.isFinal(modifiers)) {
                        htmlHeader += "final ";
                    }

                    htmlHeader += method.getReturnType().getTypeName() + " ";
                    htmlHeader += method.getName() + " (";

                    Class<?>[] parameterTypes = method.getParameterTypes();
                    for (int i = 0; i < parameterTypes.length; i++) {
                        htmlHeader += parameterTypes[i].getTypeName();
                        if (i < parameterTypes.length - 1) {
                            htmlHeader += ", ";
                        }
                    }

                    htmlHeader += ")";

                    htmlHeader += "</h3>";
                }
            }

            String htmlFooter = """
            </body>
            </html>
            """;

            Path documentationFilePath = Paths.get("dat\\documentation.html");

            String fullHtml = htmlHeader + htmlFooter;

            Files.write(documentationFilePath, fullHtml.getBytes());
            DialogUtils.showDialog(Alert.AlertType.INFORMATION, "File created!",
                    "Creation of HTML documentation file succeeded!");
        }
        catch (IOException | ClassNotFoundException ex) {
            DialogUtils.showDialog(Alert.AlertType.INFORMATION, "File not created!",
                    "Creation of HTML documentation file failed!");
        }
    }
}
