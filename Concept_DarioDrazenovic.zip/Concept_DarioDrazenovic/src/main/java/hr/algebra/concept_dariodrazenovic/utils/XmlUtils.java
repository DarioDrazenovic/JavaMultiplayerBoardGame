package hr.algebra.concept_dariodrazenovic.utils;

import hr.algebra.concept_dariodrazenovic.controller.HelloController;
import hr.algebra.concept_dariodrazenovic.model.GameMove;

import javafx.scene.control.Button;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class XmlUtils {

    private static final String FILENAME = "xml/game_moves.xml";
    private static final ReadWriteLock lock = new ReentrantReadWriteLock();
    private static final Lock writeLock = lock.writeLock();
    private static final Lock readLock = lock.readLock();
    public static HelloController controller;
    public static synchronized void saveGameMove(GameMove gameMove) {
        writeLock.lock();
        try {
            Thread currentThread = Thread.currentThread();
            System.out.println("Write lock acquired in saveGameMove method by thread: " + currentThread.getName() + " (ID: " + currentThread.getId() + ")");
            printThreadStates();

            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document;

            new Timer().scheduleAtFixedRate(new TimerTask(){
                @Override
                public void run(){
                    readGameMovesAndReplay(controller);
                }
            },0,5000);
            File file = new File(FILENAME);

            if (file.exists()) {
                document = documentBuilder.parse(file);
            } else {
                document = documentBuilder.newDocument();
                Element rootElement = document.createElement("gameMoves");
                document.appendChild(rootElement);
            }

            Element gameMoveElement = createGameMoveElement(document, gameMove);
            document.getDocumentElement().appendChild(gameMoveElement);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(file);
            transformer.transform(source, result);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            writeLock.unlock();
            System.out.println("Write lock released in saveGameMove method.");
        }
    }
    private static Element createGameMoveElement(Document document, GameMove gameMove) {
        Element gameMoveElement = document.createElement("gameMove");

        Element playerIdElement = document.createElement("playerId");
        playerIdElement.appendChild(document.createTextNode(gameMove.getPlayerId()));
        gameMoveElement.appendChild(playerIdElement);

        Element wordElement = document.createElement("word");
        wordElement.appendChild(document.createTextNode(gameMove.getWord()));
        gameMoveElement.appendChild(wordElement);

        Element dateTimeElement = document.createElement("dateTime");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        dateTimeElement.appendChild(document.createTextNode(gameMove.getDateTime().format(formatter)));
        gameMoveElement.appendChild(dateTimeElement);

        Element clickedButtonsElement = document.createElement("clickedButtons");
        for (String button : gameMove.getClickedButtons()) {
            Element buttonIdElement = document.createElement("buttonId");
            buttonIdElement.appendChild(document.createTextNode(button));
            clickedButtonsElement.appendChild(buttonIdElement);
        }
        gameMoveElement.appendChild(clickedButtonsElement);

        return gameMoveElement;
    }

    public static synchronized void readGameMovesAndReplay(HelloController controller) {
        readLock.lock();
        try {
            Thread currentThread = Thread.currentThread();
            System.out.println("Read lock acquired in readGameMovesAndReplay method by thread: " + currentThread.getName() + " (ID: " + currentThread.getId() + ")");
            printThreadStates();

            File file = new File(FILENAME);

            if (!file.exists()) {
                return;
            }

            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();

            DefaultHandler handler = new DefaultHandler() {
                private GameMove currentGameMove;
                private StringBuilder currentElementValue;
                private List<String> currentButtonIds;

                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) {
                    currentElementValue = new StringBuilder();

                    if (qName.equals("gameMove")) {
                        currentGameMove = new GameMove(null, null, null, null);
                    } else if (qName.equals("clickedButtons")) {
                        currentButtonIds = new ArrayList<>();
                    }
                }

                @Override
                public void characters(char[] ch, int start, int length) {
                    currentElementValue.append(ch, start, length);
                }

                @Override
                public void endElement(String uri, String localName, String qName) {
                    if (qName.equals("gameMove")) {
                         controller.replayMove(currentGameMove);
                    } else if (qName.equals("playerId")) {
                        currentGameMove.setPlayerId(currentElementValue.toString().trim());
                    } else if (qName.equals("word")) {
                        currentGameMove.setWord(currentElementValue.toString().trim());
                    } else if (qName.equals("dateTime")) {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                        LocalDateTime dateTime = LocalDateTime.parse(currentElementValue.toString().trim(), formatter);
                        currentGameMove.setDateTime(dateTime);
                    } else if (qName.equals("clickedButtons")) {
                        currentGameMove.setClickedButtons(currentButtonIds);
                    } else if (qName.equals("buttonId")) {
                        String buttonId = currentElementValue.toString().trim();
                        currentButtonIds.add(buttonId);
                    }

                    synchronized (lock) {
                        lock.notify();
                        System.out.println("Notification sent after processing XML element.");
                        ForNotify();
                    }
                }
            };

            saxParser.parse(file, handler);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            readLock.unlock();
            System.out.println("Read lock released in readGameMovesAndReplay method.");
        }


    }
    private static void printThreadStates() {
        Thread.getAllStackTraces().forEach((thread, stackTrace) -> {
            Thread.State state = thread.getState();
            if (state == Thread.State.WAITING || state == Thread.State.RUNNABLE) {
                System.out.println("Thread state: " + state);
                System.out.println("Thread name: " + thread.getName() + " (ID: " + thread.getId() + ")");
            }
        });
    }
    private static void ForNotify() {
        Thread.getAllStackTraces().forEach((thread, stackTrace) -> {
            Thread.State state = thread.getState();
            if (state == Thread.State.WAITING || state == Thread.State.RUNNABLE) {
                System.out.println("thread STATE 2: " + state);
                System.out.println("thread name 2: " + thread.getName() + " (ID: " + thread.getId() + ")");
            }
        });
    }

}
