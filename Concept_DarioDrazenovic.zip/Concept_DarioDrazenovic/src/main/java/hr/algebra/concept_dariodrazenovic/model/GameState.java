package hr.algebra.concept_dariodrazenovic.model;

import java.io.Serializable;
import java.util.List;

public class GameState implements Serializable {
    private List<String> clickedButtons;
    private Integer secondsRemaining;
    private Integer clickCount;
    private String correctWord;
    private Boolean threeClicksDone;

    public GameState(List<String> clickedButtons, int secondsRemaining, int clickCount, String correctWord, boolean threeClicksDone) {
        this.clickedButtons = clickedButtons;
        this.secondsRemaining = secondsRemaining;
        this.clickCount = clickCount;
        this.correctWord = correctWord;
        this.threeClicksDone = threeClicksDone;
    }

    public List<String> getClickedButtons() {
        return clickedButtons;
    }

    public int getSecondsRemaining() {
        return secondsRemaining;
    }

    public int getClickCount() {
        return clickCount;
    }

    public String getCorrectWord() {
        return correctWord;
    }

    public boolean isThreeClicksDone() {
        return threeClicksDone;
    }
}
