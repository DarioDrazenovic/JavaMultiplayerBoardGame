package hr.algebra.concept_dariodrazenovic.model;

public class ReplayManager {
    private boolean isReplaying = false;

    public synchronized boolean isReplaying() {
        System.out.println("isReplaying: " + isReplaying);
        return isReplaying;
    }

    public synchronized void startReplay() {
        System.out.println("Replay started");
        isReplaying = true;
    }

    public synchronized void endReplay() {
        System.out.println("Replay ended");
        isReplaying = false;
        notifyAll();
    }

    public synchronized void waitForReplay() throws InterruptedException {
        System.out.println("Waiting for replay");
        while (isReplaying) {
            wait();
        }
        System.out.println("Replay finished");
    }
}
