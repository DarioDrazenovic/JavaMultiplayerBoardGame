package hr.algebra.concept_dariodrazenovic.utils;

import javafx.scene.control.Alert;

public class DialogUtils {

    private static void showInformationDialog(String title, String header, String contentText) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(contentText);
        alert.showAndWait();
    }

    public static void displayWinner() {
        showInformationDialog("Congratulations!", "You've won!",
                "You guessed the correct word!");
    }
    public static void displaySaveSuccessMessage() {
        showInformationDialog("Game saved!", "Game save succeeded!",
                "You have saved your game!");
    }

    public static void displayLoadSuccessMessage() {
        showInformationDialog("Game loaded!", "Game load succeeded!",
                "You have loaded your game!");
    }
    public static void displayLoadErrorMessage() {
        showInformationDialog("Game failed to load!", "Game load failed!",
                "You have failed to load your game!");
    }

    public static void showDialog(Alert.AlertType alertType,
                                  String title, String message)
    {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
