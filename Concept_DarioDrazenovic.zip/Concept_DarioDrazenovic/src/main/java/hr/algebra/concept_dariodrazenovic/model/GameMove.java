package hr.algebra.concept_dariodrazenovic.model;

import javafx.scene.control.Button;

import java.time.LocalDateTime;
import java.util.List;

public class GameMove {
    private String playerId;
    private String word;
    private LocalDateTime dateTime;
    private List<String> clickedButtons;

    public GameMove(String playerId, String word, LocalDateTime dateTime, List<String> clickedButtons) {
        this.playerId = playerId;
        this.word = word;
        this.dateTime = dateTime;
        this.clickedButtons = clickedButtons;
    }

    public String getPlayerId() {
        return playerId;
    }

    public void setPlayerId(String playerId) {
        this.playerId = playerId;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public List<String> getClickedButtons() {
        return clickedButtons;
    }

    public void setClickedButtons(List<String> clickedButtons) {
        this.clickedButtons = clickedButtons;
    }

}